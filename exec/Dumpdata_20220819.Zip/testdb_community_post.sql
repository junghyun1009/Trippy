-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a506.p.ssafy.io    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community_post`
--

DROP TABLE IF EXISTS `community_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post` (
  `community_post_id` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `category` int NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `end_age` int NOT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `meeting_time` datetime(6) DEFAULT NULL,
  `recruit_current_volume` int NOT NULL,
  `recruit_volume` int NOT NULL,
  `start_age` int NOT NULL,
  `start_date` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `location_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `day` bit(1) NOT NULL DEFAULT b'1',
  `local` bit(1) NOT NULL DEFAULT b'1',
  `open_kakao_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`community_post_id`),
  KEY `FK5voin9s2s70bvc490h58p0e9j` (`location_id`),
  KEY `FK9buqndfbuvj4hrmvl2ypdfk9g` (`member_id`),
  CONSTRAINT `FK5voin9s2s70bvc490h58p0e9j` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `FK9buqndfbuvj4hrmvl2ypdfk9g` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post`
--

LOCK TABLES `community_post` WRITE;
/*!40000 ALTER TABLE `community_post` DISABLE KEYS */;
INSERT INTO `community_post` VALUES (728,'2022-08-15 07:36:02.867765','2022-08-15 07:39:07.302510',5,'해야된다고',19,NULL,'누구나','2022-08-15 07:35:00.000000',0,1,19,'2022-08-14 15:00:00.000000','북마크',6,693,'ㅇㅇ',_binary '',_binary '',NULL),(729,'2022-08-15 07:36:56.889355','2022-08-15 07:36:56.889355',1,'빵 맛집 찾기',70,NULL,'누구나','2022-08-15 07:36:00.000000',0,4,19,'2022-08-14 15:00:00.000000','나랑 빵집 투어 갈 사람~',6,597,'안국역',_binary '',_binary '',NULL),(1080,'2022-08-16 11:00:58.050566','2022-08-16 11:00:58.050566',1,'ㄴㅇ',70,NULL,'누구나','2022-08-16 11:00:00.000000',0,2,19,'2022-08-15 15:00:00.000000','ㅇㄴ',8,597,'ㅇㄹㄴ',_binary '',_binary '',NULL),(1172,'2022-08-16 14:55:46.676671','2022-08-16 14:55:46.676671',1,'xvcbxvcb',52,NULL,'누구나','2022-08-16 14:51:00.000000',0,2,19,'2022-08-15 15:00:00.000000','vvv',7,280,'xvbxvb',_binary '',_binary '',NULL),(1176,'2022-08-16 15:30:12.646681','2022-08-16 15:30:12.646681',2,'구해용',70,NULL,'누구나','2022-08-17 08:29:00.000000',0,1,19,'2022-08-19 15:00:00.000000','야구장 갈 사람',6,1028,'잠실야구장',_binary '',_binary '',NULL),(1177,'2022-08-16 15:31:02.237322','2022-08-16 15:31:02.237322',2,'구해용',70,NULL,'누구나','2022-08-17 08:30:00.000000',0,1,19,'2022-08-19 15:00:00.000000','야구장 갈 사람',6,1028,'잠실야구장',_binary '',_binary '',NULL),(1218,'2022-08-16 17:23:06.701947','2022-08-16 17:23:06.701947',1,'뱃지만 나오면 밥 안먹어도 됨',48,NULL,'누구나','2022-08-16 17:22:00.000000',0,2,19,'2022-08-23 15:00:00.000000','뱃지 나와라',7,1203,'구디역',_binary '',_binary '',NULL),(1220,'2022-08-16 17:23:46.440664','2022-08-16 17:23:46.440664',1,'외않되?',70,NULL,'누구나','2022-08-16 17:23:00.000000',0,1,42,'2022-08-16 15:00:00.000000','으잉',7,1203,'구디',_binary '',_binary '',NULL),(1228,'2022-08-16 17:33:03.090656','2022-08-16 17:33:03.090656',1,'밥먹자 아무나',46,NULL,'여성만','2022-08-17 03:32:00.000000',0,2,19,'2022-08-16 15:00:00.000000','마지막 뱃지를 위한 여정',6,1221,'서울대입구역',_binary '',_binary '\0',NULL),(1230,'2022-08-16 17:35:04.874856','2022-08-16 17:35:04.874856',2,'두산 야구!',70,NULL,'누구나','2022-08-16 17:34:00.000000',0,3,19,'2022-08-16 15:00:00.000000','나랑 야구장 갈 사람',6,1168,'종합운동장역',_binary '',_binary '',NULL),(1232,'2022-08-16 17:37:54.798005','2022-08-16 17:37:54.798005',3,'놀자놀아',70,NULL,'누구나','2022-08-16 21:37:00.000000',0,10,19,'2022-08-16 15:00:00.000000','나 아마 동행찾기는 첨일껄',6,280,'다모여',_binary '',_binary '\0',NULL),(1236,'2022-08-16 17:41:05.462077','2022-08-16 17:41:05.462077',2,'뱃지',70,NULL,'누구나','2022-08-16 17:40:00.000000',0,1,19,'2022-08-16 15:00:00.000000','한놈만패',6,1233,'구디로 와라',_binary '',_binary '',NULL),(1297,'2022-08-17 06:56:39.228508','2022-08-17 06:56:39.228508',1,'구합니다',70,NULL,'누구나','2022-08-17 06:56:00.000000',0,0,19,'2022-08-16 15:00:00.000000','피자먹으실분',6,1028,'피자집',_binary '',_binary '','https://www.notion.so/TRIPPY-a183e6390df6452cbe07e5d137987aab'),(1618,'2022-08-19 01:28:32.452092','2022-08-19 01:28:32.452092',4,'같이 올라가진 않아도 됩니다',35,NULL,'여성만','2022-08-18 20:30:00.000000',0,0,25,'2022-08-24 15:00:00.000000','제주 한라산 새벽 택시팟 구해요~~',15,1028,'서귀포시',_binary '',_binary '','https://open.kakao.com/o/gbbozewe'),(1625,'2022-08-19 01:33:28.324009','2022-08-19 01:33:28.324009',1,'저와식사하실 레이디분 구해요',49,NULL,'여성만','2022-08-19 01:32:00.000000',0,0,19,'2022-08-18 15:00:00.000000','왕자와 식사찬스',18,1458,'스테이크 하우스',_binary '',_binary '','개인챗으로 ^^');
/*!40000 ALTER TABLE `community_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:17:50

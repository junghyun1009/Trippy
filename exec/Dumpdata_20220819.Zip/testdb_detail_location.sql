-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a506.p.ssafy.io    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail_location`
--

DROP TABLE IF EXISTS `detail_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_location` (
  `detail_location_id` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `detail_location_content` varchar(255) NOT NULL,
  `detail_location_name` varchar(255) NOT NULL,
  `img_path` varchar(255) DEFAULT NULL,
  `rating` float NOT NULL,
  `post_id` bigint DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `location_id` bigint DEFAULT NULL,
  PRIMARY KEY (`detail_location_id`),
  KEY `FKewi9tq0vt51nnfkjensvuecoy` (`post_id`),
  KEY `FKnq97hb6l0d06kpb7tmfmrfpn7` (`location_id`),
  CONSTRAINT `FKewi9tq0vt51nnfkjensvuecoy` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`),
  CONSTRAINT `FKnq97hb6l0d06kpb7tmfmrfpn7` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_location`
--

LOCK TABLES `detail_location` WRITE;
/*!40000 ALTER TABLE `detail_location` DISABLE KEYS */;
INSERT INTO `detail_location` VALUES (346,'2022-08-12 13:13:34.480207','2022-08-12 13:13:34.480207','11','1',NULL,4,345,'static/fEIUYJqCYNKYXIoGdHDTvyGdOYlEOTsl.png',NULL),(350,'2022-08-12 13:14:41.926173','2022-08-12 13:14:41.926173','22','2',NULL,3.5,349,'static/MFtSSiYyJPKtHMzcaIQphyjvJLoprKIG.png',NULL),(366,'2022-08-12 13:20:50.865751','2022-08-12 13:20:50.865751','22','2',NULL,3.5,365,'static/jdYkXqokaOxVyBpmpqTCeKbOQNmixqFv.',NULL),(672,'2022-08-15 04:42:28.279198','2022-08-15 04:42:28.279198','직원들 친절함. 근데 사람 개많아~~','스타벅스 일호점',NULL,4.5,671,'static/pUgDTWIgkVjcCZnOwMEbCoQqfgIBIJWH.png',NULL),(824,'2022-08-15 15:14:15.369087','2022-08-15 15:14:15.369087','회한사바리 해야지예','광안리',NULL,5,823,'static/yklYvdgxSKLYVjZDHUsxAcyMazmXCMVM.png',NULL),(1070,'2022-08-16 10:39:19.533742','2022-08-16 10:39:19.533742','그전에 뱃지를 먼저 받을거야 ','롯데월드가고싶어',NULL,5,1069,'static/uMFXQLzSdejrZwbNNTDogjUGVLyQcVaj.png',NULL),(1185,'2022-08-16 15:51:52.037028','2022-08-16 15:51:52.037028','나는야 자연을 사랑하는 사람','한라산 갈건데?',NULL,5,1184,'static/wLnZHjewTWDPqXHxxsODmefsFYGllDcQ.png',NULL),(1189,'2022-08-16 15:52:39.434223','2022-08-16 15:52:39.434223','11','1',NULL,4,1188,'static/ynpAdRXDPYQXGPVEfudWdVqsdFBnjEQI.jpg',NULL),(1190,'2022-08-16 15:52:39.446378','2022-08-16 15:52:39.446378','22','2',NULL,3.5,1188,NULL,NULL),(1198,'2022-08-16 16:20:13.703307','2022-08-16 16:20:13.703307','불꽃놀이함','광안대교',NULL,3.5,1197,'static/HUmMZpZHeKDyMTcgjXpisScgxegQmvpZ.png',NULL),(1199,'2022-08-16 16:20:13.772288','2022-08-16 16:20:13.772288','서핑서핑','송정해수욕장',NULL,4.5,1197,'static/QYEvEpvDaNVQZsgiBRVNZiXGYXbcfOpR.png',NULL),(1206,'2022-08-16 16:26:59.639518','2022-08-16 16:26:59.639518','걍그려~노잼~','여긴 첨이지?',NULL,3,1205,'static/GCGMbDSDOFkJlMgXtEiHhCnDNcqexbLs.png',NULL),(1214,'2022-08-16 16:27:41.132954','2022-08-16 16:27:41.132954','또 뜨면 죽여버릴거야','구디역',NULL,3,1213,'static/SuiyFUgliMeIIxXaELeoVVMYcWUAwGWj.png',NULL),(1224,'2022-08-16 17:32:05.129520','2022-08-16 17:32:05.129520','넘좋다공','한강공원 따릉이',NULL,5,1223,'static/oacEFngdUnghOioIJZIzqDTLrYsEiGld.png',NULL),(1290,'2022-08-17 06:42:20.709199','2022-08-17 06:42:20.709199','작긴 하지만 오션뷰 리조트!','유쿠리나 리조트',NULL,5,1270,'static/mDLbnMPwNRRwMTRNABQYPooTKsSLyrvj.jpg',NULL),(1291,'2022-08-17 06:42:20.984783','2022-08-17 06:42:20.984783','오우 일본이라 그런지 초밥 레일이 역삼역 에스컬레이터보다 길었어유','히마 스시',NULL,0,1270,'static/VGcmBrgXroFOULJdnURmiuNIUPLSrxle.jpg',NULL),(1374,'2022-08-17 17:31:16.483950','2022-08-17 17:31:16.483950','날이 너무 더웠던 것만 빼면 너무 좋았습니다 ?','나무농장',NULL,4,1373,'static/rzWJATRzPISjfpEtpXZZvpypNEefrWkp.jpeg',NULL),(1375,'2022-08-17 17:31:16.644622','2022-08-17 17:31:16.644622','크 먹는거 빠질수없지?','월아산 산기슭',NULL,5,1373,'static/pAXkJnhdsPyNCLzgSvKnUzCgKRCCzVyZ.jpeg',NULL),(1384,'2022-08-17 17:52:19.147973','2022-08-17 17:52:19.147973','나고야는 온천이 유명하니까 꼭 가보세요!','나고야 료칸',NULL,5,1383,'static/fvpvHADlQPLNcRxEBnLmfxCbTWTIaTVZ.jpg',NULL),(1385,'2022-08-17 17:52:19.330605','2022-08-17 17:52:19.330605','내가 갔을 땐 공사 중이었어','나고야 성',NULL,3.5,1383,'static/ofcSuxzoIGvqQXuWurCgVaevFKPszVMe.jpg',NULL),(1386,'2022-08-17 17:52:19.451454','2022-08-17 17:52:19.451454','어른들이 탈 건 별로 없는데 귀여운 게 많아서 좋았다','레고랜드',NULL,5,1383,'static/ReIeVKamEWZqgIbnKGyWUGozwxvKMjqf.jpg',NULL),(1412,'2022-08-18 01:17:00.328978','2022-08-18 01:17:00.328978','에펠탑 여행 중 아랍 여행객이 한 컷 찍어줬다. 신기한 경험이였다. 24살의 나는 정말 젋었다. 낯설다.','파리 에펠탑',NULL,4.5,1411,'static/qagRMMKufcnNaqKjbPkpVPzdcxqLrryx.jpg',NULL),(1419,'2022-08-18 01:23:40.218696','2022-08-18 01:23:40.218696','오늘 에펠탑에 친구와 함께 갔다. 듣던대로 정말 멋있었다. 아래 사진은 내 친구가 한 컷 찍어주었다. 내 외모에 10분의 1도 안 담겼지만  그래도 나름 만족스러운 결과물이다.','브헝리가 에펠탑',NULL,4.5,1418,'static/DrOQlvkOTlfjpmWbQTqnOzuLvNXHSNKw.jpg',NULL),(1429,'2022-08-18 02:04:38.456253','2022-08-18 02:04:38.456253','마드리드에서 한잔 헤헤헤  술 안주로 망고가 참 맛있었당','마드리드',NULL,4,1428,'static/rLEfmSIFPKGluQIXAJpvchRFNgtPNsLZ.jpg',NULL),(1434,'2022-08-18 02:07:29.102145','2022-08-18 02:07:29.102145','아틀레티코 마드리드와 처음 들어본 상대팀과의 경기\n축구에 관심이 없던 나도 상당히 재밌게 봤었다.','완다 메트로폴리타노',NULL,5,1433,'static/aTgDdEABanRpXbFWQKQmERVBKdtIpWyJ.jpg',NULL),(1439,'2022-08-18 02:12:21.337129','2022-08-18 02:12:21.337129','너무 힘든 하루였다. 하루에 너무 많이 걸어서 앉을 곳이 필요했던 하루였다. 그래도 밤에 보는 로마는 참 이뻤다.','로마',NULL,3,1438,'static/risjFhemxltJcmuGdqUvHrLgJodGJZrc.jpg',NULL),(1440,'2022-08-18 02:12:21.437514','2022-08-18 02:12:21.437514','이 날은 날도 선선하고 하늘이 너무 이뻤다. 사진은 밤에 찍은 로마 길거리지만 낮에 찍은 사진도 곧 업로드할 예정입니당','로마',NULL,5,1438,'static/AKYDBkFWdAagzxcbXQMAbVvxDaHyqGHU.jpg',NULL),(1446,'2022-08-18 02:26:34.849601','2022-08-18 02:26:34.849601','스페인 대사관 앞에서 한 컷\n신난 나, 귀엽다','바르셀로나',NULL,5,1445,'static/FBIMxIPgXqnmlgxIUprTlrIzgEHRafOp.jpg',NULL),(1447,'2022-08-18 02:26:34.952838','2022-08-18 02:26:34.952838','휴식을 위해서 들어온 술집\n동네 술집이라 그런지 정겹다','바르셀로나',NULL,4.5,1445,'static/IuGHqikHFmjFfBQaTVOcpAyJLuCoHqYv.jpg',NULL),(1474,'2022-08-18 04:13:03.244676','2022-08-18 04:13:03.244676','내가 살고있는 궁전입니다. 원하시면 놀러오세요','베르사유 궁전',NULL,5,1460,'static/OjrWULFAGJeOtUZvIEfzOvtopawNWRZY.jfif',NULL),(1593,'2022-08-18 22:02:03.495647','2022-08-18 22:02:03.495647','돌고래 인형과 함께~!~','추라우미 수족관',NULL,5,1592,'static/eIpFbAAOkNAHpzsaSzIRXODjchFhjkCo.jpg',NULL),(1594,'2022-08-18 22:02:03.620686','2022-08-18 22:02:03.620686','아침에 봐도 예쁘고 낮에 봐도 예쁘고 저녁에 봐도 예쁘다','오키나와 바다',NULL,5,1592,'static/uMGIAJzwReEfMTOLewXgeAHSUEcYvXTf.jpg',NULL),(1595,'2022-08-18 22:02:03.695999','2022-08-18 22:02:03.695999','색감이 미쳤어여~\n랍스타 저기는 안 가봤는데 가보신 분!','아메리칸 빌리지',NULL,5,1592,'static/fAfzbHByvDLIUwBdytLcPqcDpWgteCuT.jpg',NULL),(1596,'2022-08-18 22:02:03.979638','2022-08-18 22:02:03.979638','반가워 아이유','오키나와 아이유',NULL,4.5,1592,'static/TvzGNadDbPJoaeLtcsPHFxtIoxLvnhaN.jpg',NULL),(1597,'2022-08-18 22:02:04.219094','2022-08-18 22:02:04.219094','호텔 앞에 있는 해수욕장인데 짱 좋았다','해수욕장',NULL,5,1592,'static/pLLOrkQmqtNGQCYoTmabFvPKQBgdHKGL.jpg',NULL),(1598,'2022-08-18 22:02:04.274598','2022-08-18 22:02:04.274598','말해뭐해~( . ̫ .)?','오키나와 고양이',NULL,5,1592,'static/NlGpiDzTELmofRUyWWHNvLNkzZYCfQYD.jpg',NULL),(1610,'2022-08-18 22:17:35.531106','2022-08-18 22:17:35.531106','잠실 야구장 돔으로 하지 마여,,,','잠실야구장',NULL,5,1609,'static/nqVSCcyyjWYLjNDpwBQLdPkumkWpcowE.jpg',NULL),(1611,'2022-08-18 22:17:35.668815','2022-08-18 22:17:35.668815','야구장은 먹으러 가는 곳이징','맥주가 맛있는 잠실 야구장',NULL,5,1609,'static/acEMgRcZYGOQgGFWydAlUiaNrmMvqTei.jpg',NULL),(1612,'2022-08-18 22:17:35.819616','2022-08-18 22:17:35.819616','난 여기는 좀 답답하더라ㅜㅜ\n그래도 가을 야구할 때 춥지는 않다!','고척스카이돔',NULL,3,1609,'static/ucrkwLQqbqWZCiWtCPUnIgGEFnTBXgHD.jpg',NULL),(1620,'2022-08-19 01:29:56.388420','2022-08-19 01:29:56.388420','힐링이 되네요~~~^*^','자연이 울창한 숲',NULL,4,1619,'static/PtrfJcjWLqNpnLpGgTrYBZuFvydyIEda.jpeg',NULL);
/*!40000 ALTER TABLE `detail_location` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:17:49

-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a506.p.ssafy.io    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `birth` datetime(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` int NOT NULL,
  `img_path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (280,'2022-08-12 08:00:02.871514','2022-08-18 19:10:33.708905','1993-07-22 06:00:00.000000','나야나','gyumin.q.lee@gmail.com',0,'static/yOQoXcoAOftqvLYuaxOjRgPMGPCbrOMG.jpg','귬니','$2a$10$AqniH3N5WB533RaNNbSY7uJ6ydbK7Xb30w5hgo0N/ulYEEBuS8YV.',NULL),(298,'2022-08-12 09:05:39.485228','2022-08-12 09:05:39.485228','1995-08-24 08:07:49.000000',NULL,'test33333@naver.com',1,NULL,'홍유진','$2a$10$TABzO0CeAoMRZAgQduTssOiyOewAOXsd1YPSJhGpUeZAPft2.mVMu','010-1111-2222'),(339,'2022-08-12 12:36:03.733297','2022-08-12 12:36:03.733297','2022-07-31 06:00:00.000000','이메일','syrok1150@gmail.com',1,'','테스트','$2a$10$TpmYHjZejdPntjY/CDx3ae45fNme6ef3vaxW/m6qLhSt.jSelMxYa',NULL),(457,'2022-08-13 08:46:01.327028','2022-08-13 08:46:01.327028','1995-08-24 08:07:49.000000',NULL,'hyj06145@naver.com',1,NULL,'홍유진','$2a$10$2LCodY2TapcVdgEoRS8/l.1EL/B8vRCLxut1Xr4j2jCE/82Ny4Jia','010-1111-2222'),(597,'2022-08-14 17:44:33.280962','2022-08-14 17:44:33.280962','1995-10-08 06:00:00.000000','이야아','cindy951009@naver.com',0,'','정현','$2a$10$jB0AmWv9amcI8D08nje16.TM6LotL2p0Be17DQ7d0uncxLnq1pERS',NULL),(688,'2022-08-15 06:49:11.292226','2022-08-15 06:49:11.292226','1995-08-24 08:07:49.000000',NULL,'test333333@naver.com',1,NULL,'홍유진','$2a$10$z/rE5mB1YaUxRZC1LEFvg.MkWrnNiXNQXJrMxqbwVY8zMbyn.GAK2','010-1111-2222'),(689,'2022-08-15 06:49:58.988149','2022-08-15 06:49:58.988149','1995-08-24 08:07:49.000000',NULL,'test3333333@naver.com',1,NULL,'홍유진','$2a$10$2vR9knXpl.Z9qU9VVJ3U8O0Gd3252sLzBvf4ek860zgczlpIcmOO2','010-1111-2222'),(691,'2022-08-15 06:51:10.577138','2022-08-15 06:51:10.577138','1995-08-24 08:07:49.000000',NULL,'test33333333@naver.com',1,NULL,'홍유진','$2a$10$kFOEm1sxb6qsZIqrVSs9EeLiqj80z.Yjk4OFj.owyHxIloRrVCGiK','010-1111-2222'),(693,'2022-08-15 06:58:24.945847','2022-08-15 06:58:24.945847','2022-08-14 06:00:00.000000','','testtest@email.com',0,'','유유유송','$2a$10$Zc4o0Ut77AYjh0JLtLrH1./uUE15I5fLTrzzsZIw0QdQ4owoNeBY2',NULL),(766,'2022-08-15 12:08:10.266520','2022-08-16 12:23:07.359155','1995-08-24 08:07:49.000000',NULL,'test323@naver.com',1,'static/uJNqBgIXdBLbWJGqZrQwDZgRAWwcUlhR.png','홍유진','$2a$10$g/as9T3BCJcjVh14WAZUpOXuM1NQI20.DW8Zcm9Wt3pI3A92C7.bu','010-1111-2222'),(768,'2022-08-15 12:08:43.004137','2022-08-15 12:08:43.004137','1995-08-24 08:07:49.000000',NULL,'trippy1234@naver.com',1,NULL,'윤트리피','$2a$10$i9g9tP90/ktAVZVeKOLh..4Bvp25E8ttwlypPmJhky0kX2WToEvIu','010-1111-2222'),(769,'2022-08-15 12:09:44.345863','2022-08-15 12:09:44.345863','1995-08-24 08:07:49.000000',NULL,'trippya506@gmail.com',1,NULL,'트리피공식','$2a$10$fKvAj/xFCDFxxpxtPIkLLO75r8KKxzRCUZHBb/fLsBToXs3VD/3kW','010-1111-2222'),(885,'2022-08-15 18:52:28.825400','2022-08-15 18:52:28.825400','2022-08-08 06:00:00.000000','나는 여행의 시작 뱃지를 가질 수 있을 것인가','badge@test.com',0,'','뱃지가질거야','$2a$10$8N9Tj.mDKF92lcCiNykj.uf3QO8vgXWNfey0V2OckQU528qwOjRca','010-1234-5678'),(908,'2022-08-16 01:38:48.283822','2022-08-16 01:38:48.283822','2022-07-12 06:00:00.000000','안녕? 나는 트리피야. 친하게 지내자!','ssafy@ssafy.com',1,'','트리피','$2a$10$V.9k1lKdviiiNuhr0z81YOmL8nkwMWS8etrENV/o3vsWXuHF.3iVO','010-1234-5678'),(1028,'2022-08-16 07:51:37.949553','2022-08-18 08:52:12.222359','2022-08-14 06:00:00.000000','','test22@email.com',0,'static/lXhhcXVUjvWQMmtgJCfNRlJogANeIiZD.jpg','유송','$2a$10$0bg9wtB7vSkSBPf.grkp9.u57WcSCDSnSZ3IlloH4Arn8WLh/6Xl6','010-1234-5678'),(1166,'2022-08-16 13:38:19.141284','2022-08-16 13:38:19.141284','2022-08-15 06:00:00.000000','','qwer@naver.com',0,'static/wIOsLCUfuSPtDACisKdNEKiFRLepLdwN.jpg','정현2','$2a$10$KCexki5U.QaK5Hf/cx2fvuPG8PsaOxU.LdaUTgEm02tH7vBJ/ZJHi','010-1234-5678'),(1168,'2022-08-16 13:47:36.149950','2022-08-16 13:47:36.149950','2022-08-14 06:00:00.000000','','asdf@naver.com',0,'static/FJzkFJnxjQoCYVLQNfigAGozVJdwtjOo.jpg','정현3','$2a$10$zor9BDY3LWIMPkYe.zucl.dGRn3pWXWubm59tQdak0XrwUs9eCwHu','010-1234-5678'),(1203,'2022-08-16 16:25:00.673735','2022-08-16 16:25:00.673735','2022-07-31 06:00:00.000000','돼주라','first@test.com',1,'static/BtMaFumTiGickuqtnKkPhajPOWyqvCIY.png','아아아','$2a$10$ySeG3muKOGvvtWjqRzzebOlWp3nqoRLBKu8iCJfOkTzd/fCHNBa5i','010-1234-1234'),(1221,'2022-08-16 17:30:50.452539','2022-08-16 17:30:50.452539','2022-07-31 06:00:00.000000','제가 3분안에 뱃지 세 개 다 모아보겠습니다','badgelast@test.com',1,'static/iIpwaydPlAsjUiHoCXEhTASBuYDMOUNs.png','뱃지테스트','$2a$10$/nYlgk5uIDu5/CHn9TNoYeM50Zjwbd8LQ0rZtToG1kEZggpFVcBgK','010-1234-1234'),(1233,'2022-08-16 17:40:35.439452','2022-08-16 17:40:35.439452','2022-07-31 06:00:00.000000','난 한놈만 패 동행찾기','community@test.com',1,'static/fmfEUKbwbLXpXjtkkKHkjxrzxrBNqZXs.png','동행찾기','$2a$10$J19QvA9Oc4u0eDziSqarweOKZf20ul63C5cU7Kau4WOR73S.0BjeS','010-1234-1234'),(1398,'2022-08-18 00:05:18.761834','2022-08-18 21:47:10.015443','1995-10-10 06:00:00.000000','바다랑 고양이가 좋아','cindy951009@korea.ac.kr',0,'static/nuEnUmndaIEWVAISSfCNoDokNeEzKHfB.jpg','찐정현','$2a$10$c.5Ci5oZjZQQXf8KqWPIv.aBQlPg7q3F/kTWhObiOd2XgWgbQ3s8u','010-5189-0650'),(1403,'2022-08-18 00:45:41.205371','2022-08-18 00:45:41.205371','1995-08-23 06:00:00.000000','나는 홍유진, 싸피 귀여움 담당이지','tommy7899@naver.com',1,'static/yjxuKUvybBRIlNMXhfYLkJpKVnAzkrpt.jpg','홍요미','$2a$10$PLDVbGejURkssHUHoCHdceNhrP4i1LxDMicv7.gqd9V3huBCl7hr.','010-5285-6983'),(1405,'2022-08-18 00:48:56.432070','2022-08-18 01:54:19.430178','1995-08-24 08:07:49.000000',NULL,'test123456@gmail.com',1,'static/XWsEXGGsHzPsjUVUvlluyMcpTjaQriXy.jpeg','윤리피','$2a$10$zUUslHSrEcjiBLZTfP0ckuMd0SWpblAYGwf7qFboHigChGlTHBiNO','010-1111-2222'),(1407,'2022-08-18 01:11:55.595186','2022-08-18 01:11:55.595186','1996-12-25 06:00:00.000000','저를 보신다면 112에 신고해주세요','ygpark@naver.com',1,'static/poDxcqVFIIxjUaHCDwvXZRUMCykPaDvD.png','범죄수사24','$2a$10$woFtIEJgpwZC.f4jshfI2eN7VDsH5GBlotQH3X4YQjAFVwV1HxEqa','010-1234-1234'),(1458,'2022-08-18 04:07:08.399551','2022-08-18 04:07:08.399551','1995-08-23 06:00:00.000000','내 눈을 바라봐 넌 행복해지고','princeyeobin@naver.com',1,'static/bQfFZSnVBuKggouRxeQHMNSthRmruRTx.jpg','여빈왕자님','$2a$10$n0gZ3tPLMKQlg9LNBp.tBeE3gWjuNgjZF.DW/kc78B1MIZJne0PeO','010-4141-5151'),(1477,'2022-08-18 04:27:31.618749','2022-08-18 04:27:31.618749','1996-12-29 06:00:00.000000','주펄','ygpark96@naver.com',1,'static/tDlIIqAngKfooHwlWigpJJXZiABvYtLn.jpg','곽튜프','$2a$10$VEOKwQyaRvEeG4NCCnyMUeQFd6Ky0H85rQcx6f2dBmmooNW1w0opC','010-1230-1230'),(1555,'2022-08-18 15:33:05.882347','2022-08-18 15:33:05.882347','1997-12-01 06:00:00.000000','사과같은 내얼굴','0312jj@naver.com',1,'static/otCJaSBBjGMeBUHQBRsybDkLpRwQkWrn.jpg','UJin','$2a$10$uFsqcesjBaedL/AvG0ujp.Eztt9oet8hvOwpCsbyXNF2Bjw312SVC','010-2222-3333'),(1567,'2022-08-18 19:13:05.157273','2022-08-18 19:13:05.157273','2022-07-31 06:00:00.000000','예~','edit@test.com',1,'static/AQrLdZCIbffczvQyAHQhIyPxVzVSWxWG.jpg','수정','$2a$10$59AHUlXL5WI8tV2xjrNhKeWidBO6Ev9PtWfEwKmv2NTynaE9pr6hK','010-1111-1111'),(1590,'2022-08-18 21:49:36.712207','2022-08-18 21:49:36.712207','1967-04-18 06:00:00.000000','ㅍ','hjw6125@naver.com',1,'static/dZttvlljzfgiWezFmmSmNiHTHLqKkVkA.jpeg','으라차차','$2a$10$URBXCc3Hn7VOIrsf204R4Oj3f0vYaaqrjcSAu1dXxy5py0/Rh.2ia','01083096125'),(1616,'2022-08-18 22:55:06.322697','2022-08-18 22:55:06.322697','1993-07-22 06:00:00.000000','✈️','leex6657@umn.edu',0,'static/wonFGtGiXWEgTxNTMHNCnQpybUeJVZnc.jpeg','규민','$2a$10$dLMyXEp3vNseqO2vaG6h8O.1BesXPg0v3PLd75ogRIooTMCTD.vN.','010-2332-7637');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:17:48

-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a506.p.ssafy.io    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post_comment`
--

DROP TABLE IF EXISTS `post_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_comment` (
  `comment_id` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `post_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `parent_id` bigint DEFAULT NULL,
  `img_path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reg_dt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `FKna4y825fdc5hw8aow65ijexm0` (`post_id`),
  KEY `FKmqxhu8q0j94rcly3yxlv0u498` (`parent_id`),
  KEY `FKmboa7oymb913tsn3k1t3i208v` (`member_id`),
  CONSTRAINT `FKmboa7oymb913tsn3k1t3i208v` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKmqxhu8q0j94rcly3yxlv0u498` FOREIGN KEY (`parent_id`) REFERENCES `post_comment` (`comment_id`),
  CONSTRAINT `FKna4y825fdc5hw8aow65ijexm0` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_comment`
--

LOCK TABLES `post_comment` WRITE;
/*!40000 ALTER TABLE `post_comment` DISABLE KEYS */;
INSERT INTO `post_comment` VALUES (745,'2022-08-15 08:29:11.882921','2022-08-15 08:29:11.882921','안녕',365,597,NULL,NULL,NULL,NULL),(815,'2022-08-15 14:57:46.358506','2022-08-15 14:57:46.358506','댓글',349,597,NULL,NULL,NULL,NULL),(819,'2022-08-15 15:01:07.014615','2022-08-15 15:01:07.014615','댓글',345,597,NULL,NULL,NULL,NULL),(820,'2022-08-15 15:04:48.651710','2022-08-15 15:04:48.651710','대댓글',345,597,819,NULL,NULL,NULL),(829,'2022-08-15 15:24:03.428161','2022-08-15 15:24:03.428161','댓글',823,597,NULL,NULL,NULL,NULL),(830,'2022-08-15 15:24:12.499333','2022-08-15 15:24:12.499333','대댓글',823,597,829,NULL,NULL,NULL),(855,'2022-08-15 16:14:20.709339','2022-08-15 16:14:20.709339','디비에 두개 저장되나 봐야지',671,597,NULL,NULL,NULL,NULL),(856,'2022-08-15 16:14:32.614737','2022-08-16 02:21:32.784387','대댓글이 왜 두개가 저장되징 수정',671,597,855,NULL,NULL,NULL),(857,'2022-08-15 16:20:26.974635','2022-08-15 16:20:26.974635','이건?',671,597,NULL,NULL,NULL,NULL),(858,'2022-08-15 16:32:16.117178','2022-08-15 16:32:16.117178','하나만 되는건가?',823,597,830,NULL,NULL,NULL),(859,'2022-08-15 16:37:30.395706','2022-08-15 16:37:30.395706','오?',671,597,857,NULL,NULL,NULL),(860,'2022-08-15 16:38:06.961494','2022-08-15 16:38:06.961494','엥?',671,597,857,NULL,NULL,NULL),(861,'2022-08-15 16:38:49.703042','2022-08-15 16:38:49.703042','다시다시',349,597,NULL,NULL,NULL,NULL),(862,'2022-08-15 16:39:00.008544','2022-08-15 16:39:00.008544','되는거야??',349,597,861,NULL,NULL,NULL),(863,'2022-08-15 16:41:32.814110','2022-08-15 16:41:32.814110','다시',365,597,NULL,NULL,NULL,NULL),(864,'2022-08-15 16:41:42.328712','2022-08-15 16:41:42.328712','진짜 되나봥',365,597,863,NULL,NULL,NULL),(934,'2022-08-16 02:34:58.485160','2022-08-16 02:34:58.485160','두개구만 왜 세개라고 하지',823,597,NULL,NULL,NULL,NULL),(935,'2022-08-16 02:35:07.798436','2022-08-16 02:35:07.798436','오잉 그러게',823,597,934,NULL,NULL,NULL),(1049,'2022-08-16 08:25:55.695765','2022-08-16 08:25:55.695765','오..?',823,597,NULL,NULL,NULL,NULL),(1241,'2022-08-16 19:18:21.212005','2022-08-16 19:18:21.212005','엇',1069,1168,NULL,NULL,NULL,NULL),(1246,'2022-08-16 19:39:04.461157','2022-08-16 19:39:04.461157','댓글!',1205,1168,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/FJzkFJnxjQoCYVLQNfigAGozVJdwtjOo.jpg','정현3',NULL),(1247,'2022-08-16 19:42:29.705493','2022-08-16 19:42:29.705493','아아',1223,1168,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/FJzkFJnxjQoCYVLQNfigAGozVJdwtjOo.jpg','정현3',NULL),(1248,'2022-08-16 19:47:22.973098','2022-08-16 19:47:22.973098','과연!',1223,597,1247,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','정현',NULL),(1249,'2022-08-16 19:47:48.538201','2022-08-16 19:47:48.538201','이번엔 내가 댓글',1223,597,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','정현',NULL),(1250,'2022-08-16 19:50:17.970896','2022-08-16 19:50:17.970896','난 대댓글',1223,1168,1249,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/FJzkFJnxjQoCYVLQNfigAGozVJdwtjOo.jpg','정현3',NULL),(1251,'2022-08-16 20:39:32.609368','2022-08-16 20:39:32.609368','내가 첫 댓글',1188,597,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','정현',NULL),(1380,'2022-08-17 17:31:51.500486','2022-08-17 17:31:51.500486','내가 내 글의 댓글도 써본다',1373,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1381,'2022-08-17 17:32:40.554412','2022-08-17 17:32:40.554412','근데 왜 404로갔ㅈ',1373,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1382,'2022-08-17 17:44:25.987270','2022-08-17 17:44:25.987270','지금 폰으로 달고 있지롱',1270,1168,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/FJzkFJnxjQoCYVLQNfigAGozVJdwtjOo.jpg','정현3',NULL),(1394,'2022-08-17 18:19:26.012010','2022-08-17 18:19:26.012010','댓글 쓰면 404 뜨는거 나만그래? ㅠㅠ',1383,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1395,'2022-08-17 18:19:42.645359','2022-08-17 18:19:42.645359','어 근데 컴퓨터로 쓰면 괜찮넹!',1383,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1401,'2022-08-18 00:26:20.462729','2022-08-18 00:26:20.462729','흐엥 왜 폰으로는 새로고침이 안되지',1383,1398,1395,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/crbOYCgPQlgnSCOhDciYwuuYwOaRKAMt.jpg','찐정현',NULL),(1409,'2022-08-18 01:14:41.652981','2022-08-18 01:14:41.652981','웹으로 할떈 문제가 없나?',1373,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1410,'2022-08-18 01:15:35.589431','2022-08-18 01:15:35.589431','다시 한번 더 ',1373,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1452,'2022-08-18 02:28:49.692170','2022-08-18 02:28:49.692170','우와 역시 스페인! 이쁘당 ★',1445,1403,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/yjxuKUvybBRIlNMXhfYLkJpKVnAzkrpt.jpg','홍요미',NULL),(1453,'2022-08-18 02:29:25.002029','2022-08-18 02:29:25.002029','나도 갈래',1445,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/ggbJfQuAbjuORstKxiWfGjYQkTPTDgMF.jpg','찐정현',NULL),(1456,'2022-08-18 02:30:43.945643','2022-08-18 02:30:43.945643','홍요미 팔로우하고 가여',1438,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/ggbJfQuAbjuORstKxiWfGjYQkTPTDgMF.jpg','찐정현',NULL),(1457,'2022-08-18 02:44:14.584842','2022-08-18 02:44:14.584842','새로고침 잘 돼라',1438,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/ggbJfQuAbjuORstKxiWfGjYQkTPTDgMF.jpg','찐정현',NULL),(1482,'2022-08-18 05:56:06.240796','2022-08-18 05:56:06.240796','놀러갈래요',1460,280,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1484,'2022-08-18 06:36:00.214654','2022-08-18 21:14:03.129163','초대해주세여~!~',1460,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/mZHfoDPVqstJcFhtOrULqxACqctCxvHw.jpg','찐정현',NULL),(1486,'2022-08-18 06:51:18.563065','2022-08-18 06:51:18.563065','아니 댓글 왜',1383,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/mZHfoDPVqstJcFhtOrULqxACqctCxvHw.jpg','찐정현',NULL),(1487,'2022-08-18 06:52:07.937440','2022-08-18 06:52:07.937440','답글은?',1383,1398,1486,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/mZHfoDPVqstJcFhtOrULqxACqctCxvHw.jpg','찐정현',NULL),(1532,'2022-08-18 08:29:40.496227','2022-08-18 08:29:40.496227','맛있겠다',1428,1028,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','유송',NULL),(1539,'2022-08-18 08:59:22.895750','2022-08-18 08:59:22.895750','역시 스포츠 경기는 먹으러 가는거징',1433,1398,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/mZHfoDPVqstJcFhtOrULqxACqctCxvHw.jpg','찐정현',NULL),(1554,'2022-08-18 10:16:33.083514','2022-08-18 10:16:33.083514','제발',1460,280,1484,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/','귬니',NULL),(1580,'2022-08-18 21:09:13.428480','2022-08-18 21:15:59.080066','(ʃƪ ˘ ³˘)',1460,1398,1484,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/iNXnKTxLCQEQAnHFWoqDznKXRcKEhHbz.jpeg','찐정현',NULL),(1633,'2022-08-19 01:36:26.561213','2022-08-19 01:36:26.561213','잘 보구.. 갑니당 ㅎㅎ.. 저도 야구 좋아해요 ^.^',1609,1458,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/bQfFZSnVBuKggouRxeQHMNSthRmruRTx.jpg','여빈왕자님',NULL),(1634,'2022-08-19 01:37:18.729732','2022-08-19 01:37:18.729732','제가 조금더 잘생겼네요 ㅎㅎ..',1418,1458,NULL,'https://trippybucket.s3.ap-northeast-2.amazonaws.com/static/bQfFZSnVBuKggouRxeQHMNSthRmruRTx.jpg','여빈왕자님',NULL);
/*!40000 ALTER TABLE `post_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:17:45
